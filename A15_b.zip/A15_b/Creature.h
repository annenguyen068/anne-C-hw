#ifndef Creature_h
#define Creature_h

#include <string>
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;
namespace cs_creature
{
    class Creature {
    private:
        int strength;           // how much damage this Creature inflicts
        int hitpoints;          // how much damage this Creature can sustain
    public:
        Creature();             // initialize to Human, 10 strength, 10 hitpoints
        Creature(int newStrength, int newHitpoints);
        
        virtual string getSpecies() const = 0;    // returns the type of the species
        virtual int getDamage() const;         // returns the amount of damage this Creature

        // also include appropriate accessors and mutators
        int getStrength() const;
        void setStrength(int newStrength);
        int getHitpoints() const;
        void setHitpoints(int newHitpoints);
    };
}

#endif
