#include "Cyberdemon.h"

using namespace std;
namespace cs_creature
{
    Cyberdemon::Cyberdemon()
    {
        setStrength(10);
        setHitpoints(10);
    }

    Cyberdemon::Cyberdemon(int newStrength, int newHitpoints)
    : demon(newStrength, newHitpoints)

    {
        setStrength(newStrength);
        setHitpoints(newHitpoints);
    }

    /*int Cyberdemon::getDamage() const
    {
        //cout << "The Cyberdemon ";
        int damage = demon::getDamage();
        return damage;
    }*/

    string Cyberdemon::getSpecies() const
    {
        return "Cyberdemon";
    }
}
