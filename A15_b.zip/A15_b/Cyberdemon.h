#ifndef Cyberdemon_h
#define Cyberdemon_h

#include "demon.h"

using namespace std;
namespace cs_creature
{
    class Cyberdemon: public demon {
    private:
    public:
        Cyberdemon();             // initialize to Cyberdemon, 10 strength, 10 hitpoints
        Cyberdemon(int newStrength, int newHitpoints);
        //int getDamage() const;         // returns the amount of damage this Creature
        string getSpecies() const;
    };
}
#endif
