#ifndef demon_h
#define demon_h

#include "Creature.h"

using namespace std;
namespace cs_creature
{
    class demon: public Creature {
    private:
    public:
        demon();             // initialize to demon, 10 strength, 10 hitpoints
        demon(int newStrength, int newHitpoints);
        virtual int getDamage() const;  // returns the amount of damage this Creature
        string getSpecies() const;    // returns the type of the species
    };
}
#endif
