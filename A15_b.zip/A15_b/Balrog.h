#ifndef Balrog_h
#define Balrog_h

#include "demon.h"

using namespace std;
namespace cs_creature
{
    class Balrog: public demon {
    private:
    public:
        Balrog();             // initialize to Balrog, 10 strength, 10 hitpoints
        Balrog(int newStrength, int newHitpoints);
        int getDamage() const;         // returns the amount of damage this Creature
        string getSpecies() const;
    };
}
#endif
