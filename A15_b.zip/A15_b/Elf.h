#ifndef Elf_h
#define Elf_h

#include "Creature.h"

using namespace std;
using namespace std;
namespace cs_creature
{
    class Elf: public Creature {
    private:
    public:
        Elf();             // initialize to Elf, 10 strength, 10 hitpoints
        Elf(int newStrength, int newHitpoints);
        string getSpecies() const;    // returns the type of the species
        int getDamage() const;         // returns the amount of damage this Creature
    };
}
#endif
