#ifndef Human_h
#define Human_h

#include "Creature.h"

using namespace std;
namespace cs_creature
{
    class Human: public Creature {
    private:
    public:
        Human();             // initialize to Human, 10 strength, 10 hitpoints
        Human(int newStrength, int newHitpoints);
        string getSpecies() const;    // returns the type of the species
        //int getDamage() const;         // returns the amount of damage this Creature
    };
}
#endif
