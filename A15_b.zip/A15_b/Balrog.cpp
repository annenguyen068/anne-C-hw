#include "Balrog.h"

using namespace std;
namespace cs_creature
{
    Balrog::Balrog()
    {
        setStrength(10);
        setHitpoints(10);
    }

    Balrog::Balrog(int newStrength, int newHitpoints)
    : demon(newStrength, newHitpoints)

    {
        setStrength(newStrength);
        setHitpoints(newHitpoints);
    }

    int Balrog::getDamage() const
    {
        //cout << "The Balrog ";
        int damage = demon::getDamage();
        int damage2 = (rand() % getStrength()) + 1;
        cout << "Balrog speed attack inflicts " << damage2 << " additional damage points!" << endl;
        damage += damage2;
        return damage;
    }

    string Balrog::getSpecies() const
    {
        return "Balrog";
    }
}
