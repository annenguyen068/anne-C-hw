/* Anh T Nguyen _ CIS 278 
 San Mateo Community College
 Assignment 15 */



#include "Human.h"
#include "Balrog.h"
#include "Elf.h"
#include "Cyberdemon.h"

using namespace cs_creature;
using namespace std;

int battleArena(Creature &Creature1, Creature& Creature2)
{
    int result = -1;
    int a1 = 1; //Creature1 attacks Creature2, i.e. Creature2's hitpoints - Creature1's damage
    int a2 = 1; //Creature2 attacks Creature1, i.e. Creature1's hitpoints - Creature2's damage
    int r = 1;
    while (a1 > 0 && a2 > 0)
    {
        cout << "Round " << r << endl;
        cout << "-";
        int d1 = Creature1.getDamage();
        int h1 = Creature1.getHitpoints();
        
        cout << "-";
        int d2 = Creature2.getDamage();
        int h2 = Creature2.getHitpoints();
        
        a1 = h2 - d1;
        a2 = h1 - d2;
        
        cout << ">" << Creature1.getSpecies() << " remaining hitpoints = " << a2 << endl;
        cout << ">" << Creature2.getSpecies() << " remaining hitpoints = " << a1 << endl;

        if (a1 <=0 && a2<= 0)
            result = 0;
        else if (a1 <= 0)
            result = 1;
        else if (a2 <= 0)
            result = 2;
        else
        {
            Creature1.setHitpoints(a2);
            Creature2.setHitpoints(a1);
        }
        cout << endl << endl;
        r ++;
    }
    return result;
}

int main()
{
    srand((time(0)));
    
    Elf c1(50,50);
    Balrog c2(50,50);;
    int result = battleArena(c1, c2);
    
    string s1 = c1.getSpecies();
    string s2 = c2.getSpecies();
    
    cout << endl << "--> Battle is over: ";
    switch (result) {
        case 0:
            cout << s1 << " drawed " << s2 << endl;
            break;
        case 1:
            cout << s1 << " defeated " << s2 << endl;
            break;
        case 2:
            cout << s2 << " defeated " << s1 << endl;
            break;
        default:
            break;
    }
}

/*Sample Output:
 
 Round 1
 -The Elf attacks for 46 points!
 -The Balrog attacks for 29 points!
 Balrog speed attack inflicts 10 additional damage points!
 >Elf remaining hitpoints = 11
 >Balrog remaining hitpoints = 4
 
 
 Round 2
 -The Elf attacks for 1 points!
 -The Balrog attacks for 12 points!
 Balrog speed attack inflicts 17 additional damage points!
 >Elf remaining hitpoints = -18
 >Balrog remaining hitpoints = 3
 
 
 
 --> Battle is over: Balrog defeated Elf
 Program ended with exit code: 0*/
