#include "Creature.h"

using namespace std;
namespace cs_creature
{
    Creature::Creature()
    {
        strength = 10;
        hitpoints = 10;
    }

    Creature::Creature(int newStrength, int newHitpoints)
    {
        strength = newStrength;
        hitpoints = newHitpoints;
    }

    int Creature::getStrength() const
    {
        return strength;
    }

    void Creature::setStrength(int newStrength)
    {
        strength = newStrength;
    }

    int Creature::getHitpoints() const
    {
        return hitpoints;
    }

    void Creature::setHitpoints(int newHitpoints)
    {
        hitpoints = newHitpoints;
    }

    int Creature::getDamage() const
    {
        int damage = (rand() % strength) + 1;
        cout << "The " << getSpecies() << " attacks for " << damage << " points!" << endl;
        return damage;
    }

    /*string Creature::getSpecies() const
    {
        return "Creature";
    }*/
}
